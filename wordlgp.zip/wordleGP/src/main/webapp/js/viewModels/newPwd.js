define([ 'knockout', 'appController', 'ojs/ojmodule-element-utils', 'accUtils',
		'jquery' ], function(ko, app, moduleUtils, accUtils, $) {

	class newPwdViewModel {
		constructor() {
			var self = this;
			
			
			self.userName = ko.observable("");
			self.email = ko.observable("");
			self.token = ko.observable(null);
			self.pwd1 = ko.observable("");
			self.pwd2 = ko.observable("");
			self.message = ko.observable();
			self.error = ko.observable();
			
			// Header Config
			self.headerConfig = ko.observable({
				'view' : [],
				'viewModel' : null
			});
			moduleUtils.createView({
				'viewPath' : 'views/header.html'
			}).then(function(view) {
				self.headerConfig({
					'view' : view,
					'viewModel' : app.getHeaderModel()
				})
			})
		}

		cambiar() {
			var self = this;
			var info = {
				userName : self.userName(),
				email : this.email(),
				token : this.token(),
				pwd1 : this.pwd1(),
				pwd2 : this.pwd2()
			};
			var data = {
				data : JSON.stringify(info),
				url : "user/cambiar",
				type : "post",
				contentType : 'application/json',
				success : function(response) {
					app.router.go( { path : "login"} );
				},
				error : function(response) {
					self.error(response.responseJSON.errorMessage);
				}
			};
			$.ajax(data);
		}
		
		recuperar() {
			var self = this;
			var info = {
				name : this.userName()
			};
			var data = {
				data : JSON.stringify(info),
				url : "user/recuperar",
				type : "post",
				contentType : 'application/json',
				error : function(response) {
					self.error(response.responseJSON.errorMessage);
				}
			};
			$.ajax(data);
		}
		
		
		enviar() {
			var self = this;
			var info = {
				userName : this.userName(),
				email : this.email()
			};
			var data = {
				data : JSON.stringify(info),
				url : "user/enviar",
				type : "put",
				contentType : 'application/json',
				success : function(response) {
				},
				error : function(response) {
					self.error(response.responseJSON.errorMessage);
				}
			};
			$.ajax(data);
		}


		connected() {
			accUtils.announce('newPwd page loaded.');
			document.title = "newPwd";
		};

		disconnected() {
			// Implement if needed
		};

		transitionCompleted() {
			// Implement if needed
		};
	}

	return newPwdViewModel;
});
