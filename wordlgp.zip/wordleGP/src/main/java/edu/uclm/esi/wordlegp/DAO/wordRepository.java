package edu.uclm.esi.wordlegp.DAO;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import edu.uclm.esi.wordlegp.model.Word;

@Repository
public interface wordRepository extends JpaRepository <Word, Integer>{

	Optional<Word> findByPosicion(int posicion); //esta interfaz manipula una tabla (que esta en la base de datos) llamada word y cuya interfaz esta en la clase string

}
