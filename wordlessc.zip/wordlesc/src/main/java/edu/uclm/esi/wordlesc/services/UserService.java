package edu.uclm.esi.wordlesc.services;


import java.util.Optional;
import java.util.Properties;
import java.util.UUID;

import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import edu.uclm.esi.wordlesc.dao.userRepository;
import edu.uclm.esi.wordlesc.model.User;



@Service
public class UserService {

	@Autowired
	private userRepository userDAO;
	
	public String register(JSONObject jso) {
		User user = new User();
		user.setUserName(jso.getString("userName"));
		user.setEmail(jso.getString("email"));
		user.setPwd(jso.getString("pwd1"));
		user.setToken(UUID.randomUUID().toString());
		user.setHora(System.currentTimeMillis());
		this.userDAO.save(user);
		return user.getToken();
	}

	public void confirmar(String token) throws Exception {
		User user=userDAO.findByToken(token);
		long time=System.currentTimeMillis();
		if(time-user.getHora()>60*15*1000) {
			throw new Exception("Token no encontrado");
		}
		user.setToken(null);
		userDAO.save(user); 
	}
	

	public User recuperar(JSONObject jso) throws Exception {
		String name = jso.getString("name");
		Optional<User> optUser = this.userDAO.findById(name);
		if (!optUser.isPresent())
			throw new Exception("Credenciales inválidas");
		User user=optUser.get();
		return user;
			
	}
	


	public User login(JSONObject jso) throws Exception {
		String name = jso.getString("name");
		String pwd = jso.getString("pwd");
		pwd = org.apache.commons.codec.digest.DigestUtils.sha512Hex(pwd);
		Optional<User> optUser = this.userDAO.findById(name);
		if (!optUser.isPresent())
			throw new Exception("Credenciales inválidas");
		User user=optUser.get();
		if(!user.getPwd().equals(pwd))
			throw new Exception("Credenciales inválidas");
		if(user.getToken()!=null)
			throw new Exception("No se ha confirmado tu registro");
		return user;
	}
	
	

	public String enviar(JSONObject jso) throws Exception {
		String name = jso.getString("userName");
		Optional<User> optUser = this.userDAO.findById(name);
		if (!optUser.isPresent())
			throw new Exception("Credenciales inválidas");
		User user=optUser.get();
		user.setToken(UUID.randomUUID().toString());
		user.setHora(System.currentTimeMillis());
		this.userDAO.save(user);
		return user.getToken();
	}

	
	
	
	
	public void tokenleido(String token) throws Exception {
		User user=userDAO.findByToken(token);
		long time=System.currentTimeMillis();
		if(time-user.getHora()>60*15*1000) {
			throw new Exception("Token no encontrado");
		}
		userDAO.save(user); 
	}
	
	public void cambiar(JSONObject jso) throws Exception {
		String name = jso.getString("userName");
		String tokenIntroducido = jso.getString("token");
		Optional<User> optUser = this.userDAO.findById(name);
		if (!optUser.isPresent())
			throw new Exception("Credenciales inválidas");
		User user=optUser.get();
		if(!tokenIntroducido.equals(user.getToken()))
			throw new Exception("El token introducido no es el mismo que se ha enciado por correo");
		user.setPwd(jso.getString("pwd1"));
		user.setToken(null);
		this.userDAO.save(user);

	}
}