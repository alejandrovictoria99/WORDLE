package edu.uclm.esi.wordlesc.dao;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;

import edu.uclm.esi.wordlesc.model.User;

public interface userRepository extends JpaRepository <User, String> {

	//User findByName(String userName);

	//User findByNameAndPwd(String name);
	User findByToken(String token);



}
